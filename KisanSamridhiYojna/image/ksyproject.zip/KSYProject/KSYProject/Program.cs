﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    class Program
    {
        static void Main(string[] args)
        {
           // Console.WindowHeight = 900;
           
            Console.ForegroundColor=ConsoleColor.Magenta;
            int LoginResult=FirstLogin.PageEntryLogin();

           if (LoginResult == 1)
            {
                Console.SetCursorPosition(50, 23);
                Console.Clear();
                HeaderFooter hf1 = new HeaderFooter();
                hf1.HeaderSection();
                HomePage hp1 = new HomePage();
                hp1.HomeSection();
                hf1.FooterSection();
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.SetCursorPosition(40, 38);
                while (true)
                {
                    Console.SetCursorPosition(69, 17);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    
                    Console.Write("Enter your choice:");
                    int ChoiseForMenu = int.Parse(Console.ReadLine());

                    switch (ChoiseForMenu)
                    {

                        case 1:
                            Console.Clear();
                            //HeaderFooter hf2 = new HeaderFooter();
                            hf1.HeaderSection();
                            //HomePage hp2 = new HomePage();
                            hp1.HomeSection();
                           // hf1.FooterSection();
                            break;
                        case 2:
                            Console.Clear();
                            //HeaderFooter hf3 = new HeaderFooter();
                            hf1.HeaderSection();
                            AboutPage ab = new AboutPage();
                            ab.AboutSection();
                            //hf1.FooterSection();
                            break;
                         case 3:
                            Console.Clear();
                            //HeaderFooter hf3 = new HeaderFooter();
                            hf1.HeaderSection();
                           GuidelinePage gl = new GuidelinePage();
                            gl.GuidelineSection();
                            //hf1.FooterSection();
                            break;
                        case 4:
                            Console.Clear();
                            hf1.HeaderSection();
                             FarmerReg fg = new FarmerReg();
                            fg.FarmerRegistration();
                            break;
                        case 5:
                            Console.Clear();
                            hf1.HeaderSection();
                            LoginPage.FormerLogin();
                            break;
                       case 6:
                            Console.Clear();
                            hf1.HeaderSection();
                            AdminLogin ad = new AdminLogin();
                            bool s = ad.AdminLogin1();
                            if (s == true)
                            {
                                Console.Clear();
                                ad.AdminDash();
                            }
                            else
                                Console.SetCursorPosition(70, 40);
                                Console.WriteLine("Invalid UserId & Password!");   
                            break;
                        case 7:
                            Environment.Exit(0);
                            break;
                          
                    }
                    hf1.FooterSection();
                }

               
            }
            else
            {
               
                Console.SetCursorPosition(50, 23);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Oops!Your trial expire......");

            }
           
        }
    }
}
