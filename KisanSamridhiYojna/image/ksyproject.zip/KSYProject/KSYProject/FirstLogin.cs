﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
   public class FirstLogin
    {
        //Method for Entry Page Login
       internal static int PageEntryLogin()
        {
            string username, password;
            int ctr = 0, dd = 0,LoginStatus=0;
            ApplicationPageHeader();
        start:
            ApplicationPageHeader();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(60, 18);
            Console.Write("||========================||\n");
            Console.SetCursorPosition(60, 19);
            Console.Write("||  Identify Yourself     ||\n");
            Console.SetCursorPosition(60, 20);
            Console.Write("||========================||\n");
            Console.SetCursorPosition(62, 22);
            Console.Write("You have three trial.\n");
            Console.SetCursorPosition(60, 30);
            Console.Write("Check username and password :\n");
            Console.SetCursorPosition(55, 31);
            Console.Write("-------------------------------------\n\n\n");
            do
            {
                Console.SetCursorPosition(60, 34);
                Console.Write("Input a username: ");
                username = Console.ReadLine();
                Console.SetCursorPosition(60, 35);
                Console.Write("Input a password: ");
             
                password = GetHidePassword();
                Console.Clear();
                if (username == "DevDelta" && password == "Dev123")
                {
                    dd = 1;
                    ctr = 3;
                }

                else
                {
                    dd = 0;
                    ctr++;
                  if(ctr!=3)
                    {
                        goto start;
                    }
                }
            }
            while ((username != "DevDelta" || password != "Dev123")
                    && (ctr != 3));
            if (dd == 0)
            {
                LoginStatus = 0;
            }
            else
            if (dd == 1)
            {
                LoginStatus = 1;
            }
            return LoginStatus;
         
        }

        //Method for Hide password
        static string GetHidePassword()
        {
            string input = "";
            ConsoleKeyInfo key;
            do
            {
                key = Console.ReadKey(true);

                // Ignore any key that is not a valid input
                if (!char.IsControl(key.KeyChar))
                {
                    input += key.KeyChar;
                    Console.Write("*"); // Display asterisk for each character
                }

            } while (key.Key != ConsoleKey.Enter);

            Console.WriteLine(); // Move to the next line after the user presses Enter
            return input;
        }

        //Method For Application Login Header
        internal static void ApplicationPageHeader()
        {
            Console.SetCursorPosition(0, 0);
            for (int i=1;i<173;i++)
            {
                Console.Write("*");
            }
            Console.WriteLine("\n");
            
            //for designing kisan Samridhi yojana
            Console.WriteLine("                      _____  __  __            _  ___                     _____                      _     _ _     _   __     __   _             \r\n                     |  __ \\|  \\/  |          | |/ (_)                   / ____|                    (_)   | | |   (_)  \\ \\   / /  (_)            \r\n                     | |__) | \\  / |  ______  | ' / _ ___  __ _ _ __    | (___   __ _ _ __ ___  _ __ _  __| | |__  _    \\ \\_/ /__  _ _ __   __ _ \r\n                     |  ___/| |\\/| | |______| |  < | / __|/ _` | '_ \\    \\___ \\ / _` | '_ ` _ \\| '__| |/ _` | '_ \\| |    \\   / _ \\| | '_ \\ / _` |\r\n                     | |    | |  | |          | . \\| \\__ \\ (_| | | | |   ____) | (_| | | | | | | |  | | (_| | | | | |     | | (_) | | | | | (_| |\r\n                     |_|    |_|  |_|          |_|\\_\\_|___/\\__,_|_| |_|  |_____/ \\__,_|_| |_| |_|_|  |_|\\__,_|_| |_|_|     |_|\\___/| |_| |_|\\__,_|\r\n                                                                                                                                 _/ |            \r\n                                                                                                                                |__/             ");


            Console.WriteLine("\n");
            for (int i = 1; i < 173; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine("\n\n");

        }
    }
}
