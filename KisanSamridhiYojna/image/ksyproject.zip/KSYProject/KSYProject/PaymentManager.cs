﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    internal class PaymentManager
    {
        public string AdharNumber { get; set; }
        public string KisanName { get; set; }
        public string KisanMob { get; set; }
        public string KisanState { get; set; }
        public string KisanPass { get; set; }
        public string KisanId { get; set; }
        public int Sno { get; set; }
        public string AppStatus { get; set; }
        public float TotalAmount { get; set; }

        public string AdminPass = "PrinceHack";
        public DateTime LastPaymentDate { get; set; }

        //Method for show registered farmers
        internal void GetFarmerDetails()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();

            MyCommand = "select * from FarmerApplyScheme";
            DataTable dt = DB.ExcuteMySelect(MyCommand);
            Console.SetCursorPosition(10, 20);
            Console.WriteLine("Adhar Number \t\t Farmer Name \t\tFarmer Mobile No \t\tFarmer State\t\tFarmer Password\t\tFarmer Id");
            //Console.SetCursorPosition(35, 11);
            // Console.WriteLine("\t-----------\t ----------\t------------- \t ------------");
            Console.WriteLine();
            foreach (DataRow dr in dt.Rows)
            {
                PaymentM.AdharNumber = dr["AdharNo"].ToString();
                PaymentM.KisanName = dr["Name"].ToString();
                PaymentM.KisanMob = dr["MobileNo"].ToString();
                PaymentM.KisanState = dr["State"].ToString();
                PaymentM.KisanPass = dr["Password"].ToString();
                PaymentM.KisanId = dr["UserId"].ToString();
                Console.WriteLine("\t| " + PaymentM.AdharNumber + "\t\t|" + PaymentM.KisanName + "\t\t|" + PaymentM.KisanMob + "\t\t\t| " + PaymentM.KisanState + "\t\t\t|" + PaymentM.KisanPass + "\t\t|" + PaymentM.KisanId + "\t");
            }


        }
        //method for farmer application
        internal void GetFarmerApplication()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();

            MyCommand = "select * from ApplyScheme";
            DataTable dt = DB.ExcuteMySelect(MyCommand);
            Console.SetCursorPosition(30, 20);
            Console.WriteLine("\tSerial No. \t\t Application Status \t\t Adhar Number \t\tCurrent Amount\t");
            //Console.SetCursorPosition(35, 11);
            // Console.WriteLine("\t-----------\t ----------\t------------- \t ------------");
            Console.WriteLine();
            foreach (DataRow dr in dt.Rows)
            {
                PaymentM.AdharNumber = dr["AdharNo"].ToString();
                PaymentM.TotalAmount = float.Parse(dr["CAmount"].ToString());
                PaymentM.AppStatus = dr["SchemeApply"].ToString();
                PaymentM.Sno = int.Parse(dr["FarmerSNo"].ToString());

                Console.WriteLine("\t\t\t\t| " + PaymentM.Sno + "\t\t\t|" + PaymentM.AdharNumber + "\t\t\t|" + PaymentM.AppStatus + "\t\t\t| " + PaymentM.TotalAmount + "\t");
            }


        }
        //Method for first installment
        internal void MakePayment1()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();
            string AdminPass = "Admin@123";
            string MyCommand1 = "Select CAmount from ApplyScheme";
            object obj = DB.GetSingleValue(MyCommand1);
            int camount = Convert.ToInt32(obj);
            //string DateToPay = string.Empty;

            DateTime currentDate = DateTime.Now;
            string CurrentDate = currentDate.ToString("yyyy-MM-dd");
            //LastPaymentDate = DateTime.Now.AddDays(-95);
            // TimeSpan difference = currentDate - LastPaymentDate;
            // int daysPassed = difference.Days;

            Console.SetCursorPosition(30, 20);
            Console.WriteLine("''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
            if (AdminPass == "Admin@123" && camount == 0)

            {
                PaymentM.TotalAmount += 2000;
                Console.SetCursorPosition(36, 23);
                Console.WriteLine("Amount Added Successfully");
                Console.SetCursorPosition(76, 23);
                MyCommand = "UPDATE ApplyScheme SET PaymentDate = '" + CurrentDate + "',CAmount='" + PaymentM.TotalAmount + "'";
                bool status = DB.ExCuteInsertUpdateOrDelete(MyCommand);
                if (status == true)
                {
                    Console.SetCursorPosition(76, 25);
                    Console.WriteLine("Row updated successfully");
                }
                else
                {
                    Console.SetCursorPosition(76, 25);
                    Console.WriteLine("Unable to update");
                }
                DB.Counting();
            }
            else
            {
                Console.SetCursorPosition(76, 26);
                Console.WriteLine("Payment cannot be made again before 3 months.");
            }
        }
        //Method for second installment
        internal void MakePayment23()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();


            string AdminPass = "Admin@123";
            string DateToPay = string.Empty;
            string MyCommand1 = "Select PaymentDate from ApplyScheme";
            object obj = DB.GetSingleValue(MyCommand1);
            DateTime tarikh = Convert.ToDateTime(obj);

            //double date = Convert.ToDouble(obj);
            DateTime currentDate = DateTime.Now;

            // LastPaymentDate = currentDate - dt;

            // LastPaymentDate = DateTime.Now.AddDays(-95);
            TimeSpan difference = currentDate - tarikh;
            int daysPassed = difference.Days;
            string CurrentDate = currentDate.ToString("yyyy-MM-dd");
            Console.SetCursorPosition(39, 20);
            Console.WriteLine("''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''");
            if (daysPassed > 90 && AdminPass == "Admin@123")

            {
                PaymentM.TotalAmount = 2000;
                PaymentM.TotalAmount += 2000;
                Console.SetCursorPosition(36, 26);
                Console.WriteLine("Amount Added Successfully");
                Console.SetCursorPosition(76, 23);
                MyCommand = "UPDATE ApplyScheme SET PaymentDate = '" + CurrentDate + "',CAmount='" + PaymentM.TotalAmount + "'";
                bool status = DB.ExCuteInsertUpdateOrDelete(MyCommand);
                if (status == true)
                {
                    Console.SetCursorPosition(57, 26);
                    Console.WriteLine("Row updated successfully");
                }
                else
                {
                    Console.SetCursorPosition(57, 25);
                    Console.WriteLine("Unable to update");
                }

                DB.Counting();

            }
            else
            {
                Console.SetCursorPosition(57, 26);
                Console.WriteLine("Payment cannot be made again before 3 months.");
            }
        }
        internal void MakePayment()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();


            Console.SetCursorPosition(48, 23);
            Console.WriteLine("Option 1 \t\t\t Option 2 \t\t\t Option 3");
            Console.SetCursorPosition(40, 24);
            Console.WriteLine("\tFirst InstallMent \t\t Second InstallMent \t\t Third InstallMent");

            Console.SetCursorPosition(21, 25);
            Console.WriteLine("Select Option-:");
            Console.SetCursorPosition(36, 25);
            int op = int.Parse(Console.ReadLine());
            switch (op)
            {
                case 1:
                    MakePayment1();
                    break;
                case 2:
                    MakePayment23();
                    break;
                case 3:
                    MakePayment23();
                    break;
                default:
                    Console.WriteLine("Invalid Selection");
                    break;
            }
        }
        //method for delete regidtered farmer
        internal void DeleteFarmerDetaails()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();


            bool status;
            Console.SetCursorPosition(55, 20);
            Console.WriteLine("Enter Adhar Farmer Aadhar Number and Password");
            Console.SetCursorPosition(55, 21);
            Console.WriteLine("---------------------------------------------");

            Console.SetCursorPosition(57, 23);
            Console.WriteLine("AdharNumber \t\t AdminPassword");

            Console.SetCursorPosition(57, 24);
            PaymentM.AdharNumber = Console.ReadLine();
            Console.SetCursorPosition(57, 26);
            Console.WriteLine("------------- \t\t ---------------");
            Console.SetCursorPosition(81, 24);
            AdminPass = Console.ReadLine();

            MyCommand = "delete from FarmerApplyScheme where AdharNo='" + PaymentM.AdharNumber + "'";
            status = DB.ExCuteInsertUpdateOrDelete(MyCommand);
            if (status == true && AdminPass == "Admin@123")
            {
                Console.SetCursorPosition(57, 28);
                Console.WriteLine("Record Deleted SuccessFully");
            }
            else
            {
                Console.SetCursorPosition(57, 28);
                Console.WriteLine("Sorry! This record is'n not available");
            }
        }
        //method for delete farmer applications
        internal void DeleteFarmerApplication()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();


            bool status;
            Console.SetCursorPosition(55, 20);
            Console.WriteLine("Enter Farmer Aadhar Number and Password");
            Console.SetCursorPosition(55, 21);
            Console.WriteLine("---------------------------------------------");

            Console.SetCursorPosition(57, 23);
            Console.WriteLine("AdharNumber \t\t AdminPassword");

            Console.SetCursorPosition(57, 24);
            PaymentM.AdharNumber = Console.ReadLine();
            Console.SetCursorPosition(57, 26);
            Console.WriteLine("------------- \t\t ---------------");
            Console.SetCursorPosition(81, 24);
            AdminPass = Console.ReadLine();

            MyCommand = "delete from ApplyScheme where AdharNo='" + PaymentM.AdharNumber + "'";
            status = DB.ExCuteInsertUpdateOrDelete(MyCommand);
            if (status == true && AdminPass == "Admin@123")
            {
                Console.SetCursorPosition(57, 28);
                Console.WriteLine("Record Deleted SuccessFully");
            }
            else
            {
                Console.SetCursorPosition(57, 28);
                Console.WriteLine("Sorry! This record is'n not available");
            }
        }
        //Method for Search individual farmers
        internal void SearchFarmerDeatails()
        {
            DBManager DB = new DBManager();
            string MyCommand = string.Empty;
            PaymentManager PaymentM = new PaymentManager();

            bool status;

            Console.SetCursorPosition(68, 20);
            Console.WriteLine("Fill CareFully Details");
            Console.SetCursorPosition(68, 21);
            Console.WriteLine("......................");

            Console.SetCursorPosition(63, 23);
            Console.WriteLine("Adhar Number \t\t Admin Password");

            Console.SetCursorPosition(64, 25);
            AdharNumber = Console.ReadLine();
            Console.SetCursorPosition(63, 26);
            Console.WriteLine("------------- \t\t ---------------");
            Console.SetCursorPosition(86, 25);
            AdminPass = Console.ReadLine();
            



            status = DB.IsDataExists(AdharNumber);
            if (status == true && AdminPass == "Admin@123")
            {
                MyCommand = "select * from FarmerApplyScheme left join ApplyScheme on FarmerApplyScheme.AdharNo=ApplyScheme.AdharNo where ApplyScheme.AdharNo='" + AdharNumber + "'";
                DataTable dt = DB.ExcuteMySelect(MyCommand);
                Console.WriteLine("\tAdhar No. \t Name \tMobile No. \t State\tApplication Status\tTotal Amount");

                foreach (DataRow dr in dt.Rows)
                {
                    PaymentM.AdharNumber = dr["AdharNo"].ToString();
                    PaymentM.TotalAmount = float.Parse(dr["CAmount"].ToString());
                    PaymentM.AppStatus = dr["SchemeApply"].ToString();
                    PaymentM.KisanName = dr["Name"].ToString();
                    PaymentM.KisanMob = dr["MobileNo"].ToString();
                    PaymentM.KisanState = dr["State"].ToString();
                    Console.WriteLine("\t" + PaymentM.AdharNumber + "\t\t" + PaymentM.KisanName + "\t\t" + PaymentM.KisanMob + "\t\t " + PaymentM.KisanState + "\t\t " + PaymentM.AppStatus + "\t\t " + PaymentM.TotalAmount);
                }

            }
            else
            {
                Console.SetCursorPosition(70, 28);
                Console.WriteLine("Sorry! This record is not available.");
            }
        }
        }
    }
