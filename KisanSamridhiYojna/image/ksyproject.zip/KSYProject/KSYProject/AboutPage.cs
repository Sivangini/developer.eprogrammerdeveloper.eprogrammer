﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    class AboutPage
    {
      

        internal void AboutSection()
        {
           
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(65, 20);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(65, 21);
            Console.WriteLine("||          ABOUT US PAGE         ||");
            Console.SetCursorPosition(65, 22);
            Console.WriteLine("||********************************||");

            Console.SetCursorPosition(65, 25);
            Console.WriteLine("There Are Something About The Site");
            Console.SetCursorPosition(64, 26);
            Console.WriteLine("--------------------------------------");
            Console.SetCursorPosition(30, 28);
            Console.WriteLine("\nThe Pradhan Mantri Kisan Samman Nidhi (PM-KISAN) is a Central" +
                " Sector Scheme that  provides financial assistance to all cultivable landholding" +
                " farmer families in India. The scheme was announced in the 2019 Interim Central Budget " +
                "by Piyush Goyal. It became operational on December 1, 2018.:");

            Console.SetCursorPosition(0, 35);
            Console.WriteLine("The scheme provides an income support of Rs. 6,000 per year in  " +
                "three equal installments of Rs. 2,000 each. The installments are deposited directly " +
                "into the farmers' bank accounts every four months. \r\n The total annual expenditure" +
                " for this scheme is expected to be Rs. 75,000 crore.");
            Console.SetCursorPosition(0, 40);
            Console.WriteLine("The scheme is 100% funded by the Government of India. The Joint Secretary and " +
                " CEO of PM-KISAN is Shri Pramod Kumar Meherda. \r\n");

            Console.SetCursorPosition(50, 42);
            Console.WriteLine("Email: contact@company.com");
            Console.SetCursorPosition(50, 43);
            Console.WriteLine("Phone: +1 (123) 456-7890");
            Console.SetCursorPosition(50, 44);
            Console.WriteLine("\nVisit our website: http://www.DevSmith.com");







            Console.SetCursorPosition(0, 45);
            Console.WriteLine("\n========================================================================================================================================================================");
           
        }
    }
}
