﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
class HeaderFooter
    {
        internal void HeaderSection()
        {
            //HomePage.ShowMenu();
           
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("                      _____  __  __            _  ___                     _____                      _     _ _     _   __     __   _             \r\n                     |  __ \\|  \\/  |          | |/ (_)                   / ____|                    (_)   | | |   (_)  \\ \\   / /  (_)            \r\n                     | |__) | \\  / |  ______  | ' / _ ___  __ _ _ __    | (___   __ _ _ __ ___  _ __ _  __| | |__  _    \\ \\_/ /__  _ _ __   __ _ \r\n                     |  ___/| |\\/| | |______| |  < | / __|/ _` | '_ \\    \\___ \\ / _` | '_ ` _ \\| '__| |/ _` | '_ \\| |    \\   / _ \\| | '_ \\ / _` |\r\n                     | |    | |  | |          | . \\| \\__ \\ (_| | | | |   ____) | (_| | | | | | | |  | | (_| | | | | |     | | (_) | | | | | (_| |\r\n                     |_|    |_|  |_|          |_|\\_\\_|___/\\__,_|_| |_|  |_____/ \\__,_|_| |_| |_|_|  |_|\\__,_|_| |_|_|     |_|\\___/| |_| |_|\\__,_|\r\n                                                                                                                                 _/ |            \r\n                                                                                                                                |__/             ");
            //Console.WriteLine("".PadLeft((Console.WindowWidth - 90) / 2)); // Centering

            // Set text colors for each option
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("+***********************************************************************************************************************************************************************++");
            Console.WriteLine   ("||+*********************************************************************************************************************************************************************||");
            Console.WriteLine("||                                                                                                                                                                      ||");
            Console.WriteLine("||          1.Home     ||     2.About     ||     3.Guideline     ||     4.Farmer Registration     ||    5.Farmer Login   ||     6.Admin Login   ||     7.Exit           ||");
            Console.WriteLine("||                                                                                                                                                                      ||");
            Console.WriteLine("||++*******************************************************************************************************************************************************************+||");
            Console.Write("++**********************************************************************************************************************************************************************++");

        }
        //footer method
        internal void FooterSection()
        {
            // Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("\n\n");
            //  Console.SetCursorPosition(0, 30);


            Console.WriteLine("****************************************************************************************************************************************************************************");
           
            Console.WriteLine("****************************************************************************************************************************************************************************");
            Console.WriteLine("\n\t\tAbout PM Kisan Found" + "\t\t\t\tQuick Links:-" + "\t\t\t\t\tAddress Info:-");
            //Console.WriteLine("\n\tThis is the site of KSY"+"\t\t\tHome"+"\t\t\t123 Main Street,Cityville,Country"+"\n\n"+"\t\t\t\t\t\t\t\t\t\tContact Info:-"+"\n\n"+ "\t\t\t\t\t\t\t\t\t\t(+91)-8236783372,8827-4653-3746"+"\n\n" +"\t\t\t\t\t\t\t\t\t\tEmail:-"+"\n\n"+ "\t\t\t\t\t\t\t\t\t\tDevSmith2023@gmail.com");
            Console.WriteLine("\n\tThis is the site of KSY Scheme" + "\t\t\t\tHome" + "\t\t\t\t\t123-Main Street,Cityville,Country");
            Console.WriteLine("\n\tthat give the fund to the " + "\t\t\t\tAbout Us" + "\t\t\t\t\tContact Info:-" + "\n" + "\t\t\t\t\t\t\t\t\t\t\t\t\t(+91)-8236783372,8827-4653-3746");
            Console.WriteLine("\tFarmer for their good agriculture" + "\t\t\tRegistration" + "\t\t\t\t\tEmail:-" + "\n" + "\t\t\t\t\t\t\t\t\t\t\t\t\tdevsmith2023@gmail.com");
            Console.WriteLine("\tproduction and profite." + "\t\t\t\t\tLogin Page");
            // Console.WriteLine("\t\tKisan Samridhi Yogna"+"\n"+"This Project is Related to The Fund for farmer familes. ");

            Console.WriteLine("\n\t\t\t\t\t\tPrivacy Policy | Terms and Conditions ");
            Console.WriteLine("****************************************************************************************************************************************************************************"); Console.WriteLine("\t\t©2023DevSmith.All Rights Reserved" + "\t\t\t\t\t\t\t\t" + "Developed By:- Team DevSmith");
            Console.WriteLine("****************************************************************************************************************************************************************************");
        }
    }
}
