﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    class GuidelinePage
    {
        internal void GuidelineSection()
        {
         
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(65, 19);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(65, 20);
            Console.WriteLine("||          GUIDELINE PAGE        ||");
            Console.SetCursorPosition(65, 21);
            Console.WriteLine("||********************************||");
            Console.WriteLine(" \n\nWith a view to provide income support to all landholding farmers’ families in the country, having cultivable land, the Central Government has implemented a Central Sector Scheme,namely, “Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)”.The scheme aims to supplement the financial needs of all landholding farmers’ families in procuring various inputs to ensure proper crop health and appropriate yields,commensurate with the anticipated farm income as well as for domestic needs. Under the Scheme an amount of Rs.6000/- per year is released by the Central Government online directly into the bank accounts of the eligible farmers under Direct Benefit Transfer mode, subject to certain exclusions.A landholder farmer’s family is defined as “a family comprising of husband, wife and minor children who owns cultivable land as per land records of the concerned State/UT”. The existing land-ownership system will be used for identification of beneficiaries for calculation of benefit.Former and present Ministers State Ministers and former present Members of Lok Sabha / Rajya Sabha / State Legislative Assemblies / State Legislative Councils, former and present Mayors of Municipal Corporations, former and present Chairpersons of District Panchayats.All serving or retired officers and employees of Central / State Government Ministries / Offices / Departments and their field units, Central or State PSEs and Attached offices / Autonomous Institutions under Government as well as regular All superannuated / retired pensioners whose monthly pension is Rs.10,000/- or more (Excluding Multi Tasking Staff / Class IV / Group D employees)All Persons who paid Income Tax in last assessment year.Professionals like Doctors, Engineers, Lawyers, Chartered Accountants, and Architects registered with Professional bodies and carrying out profession by undertaking practices.In case of new beneficiaries being uploaded on the PM-KISAN Portal, all land holding farmers’ families who are Non-resident Indians (NRIs) in terms of the provisions of the Income Tax Act, 1961 shall be excluded from any benefit under the Scheme. For the purpose of exclusion State / UT Governments can certify the eligibility of the beneficiaries based on self declaration by the beneficiaries. In case beneficiary is not available / does not reside in the village, State / UT Governments may consider certification based on the declaration by other adult member of his / her family. In case of incorrect self declaration, beneficiary shall be liable for recovery of transferred financial benefit and other penal actions as per law--------------------");
            Console.WriteLine("\n\n");

            Console.WriteLine("                                                            Email: contact@company.com");
            Console.WriteLine("                                                            Phone: +1 (123) 456-7890");

            Console.WriteLine("                                                            Visit our website: http://www.DevSmith.com");








            Console.WriteLine("\n=========================================================================================================================================================================");
         
        }
    }
}
