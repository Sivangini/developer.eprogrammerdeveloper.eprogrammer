﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    internal class DBManager
    {
        SqlConnection con;

        public DBManager()
        {
            con = new SqlConnection("Data Source=SUBHAM\\SQLEXPRESS;Initial Catalog=KSYDB; Integrated Security=True;");
        }
        internal bool ExCuteInsertUpdateOrDelete(string CommandText)
        {
            SqlCommand cmd = new SqlCommand(CommandText, con);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            int n = cmd.ExecuteNonQuery();
            con.Close();
            return n > 0 ? true : false;
        }
        //MUltiple DataTable
        internal DataTable ExcuteMySelect(string CommandText)
        {
            SqlDataAdapter da = new SqlDataAdapter(CommandText, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        internal void Counting()
        {

            int count;
            using (SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM ApplyScheme", con))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                count = (int)command.ExecuteScalar();

                con.Close();
            }
            Console.WriteLine("Total farmer Payment Successfully: " + count);
        }
        internal Object GetSingleValue(string CommandText)
        {
            SqlCommand cmd = new SqlCommand(CommandText, con);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            object res = cmd.ExecuteScalar();
            con.Close();
            return res;
        }
        internal bool IsDataExists(string AdharNumber)
        {
            string CommandText = "select * from ApplyScheme where AdharNo='" + AdharNumber + "'";
            object obj = GetSingleValue(CommandText);
            return obj != null ? true : false;
        }
    }
}
