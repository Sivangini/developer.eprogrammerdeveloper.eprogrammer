﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace KSYProject
{
    class FarmerReg
    {
        internal static string cap;
        internal void FarmerRegistration()
        {
            bool Status = true;
           
            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(65, 19);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(65, 20);
            Console.WriteLine("||     FARMER REGISTRATION PAGE   ||");
            Console.SetCursorPosition(65, 21);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(40, 27);
            Console.WriteLine("||-------------------------------------------------------------------------------------------||");
            Console.SetCursorPosition(40, 29);
            Console.WriteLine("||                                                                                           ||");
            Console.SetCursorPosition(40, 31);
                Console.Write("||               Enter Adhar number:-                                                        ||");
            Console.SetCursorPosition(80, 31);

            pm.AdharNo = Console.ReadLine();
            Console.SetCursorPosition(40, 33);
                Console.Write("||               Enter Your Name:-                                                           ||");

            Console.SetCursorPosition(80, 33);
            pm.Name = Console.ReadLine();
            Console.SetCursorPosition(40, 35);
                Console.Write("||               Enter Mobile Number:                                                        ||");
            Console.SetCursorPosition(80, 35);
            pm.MobileNo = Console.ReadLine();
            //pm.MobileNo = Console.ReadLine();
            Console.SetCursorPosition(40, 37);
                Console.Write("||               Enter your state                                                            ||");
            Console.SetCursorPosition(80, 37);
            pm.State = Console.ReadLine();
            //pm.State = Console.ReadLine();
            Console.SetCursorPosition(40, 39);
                Console.Write("||               Enter Password:                                                             ||");
            // pm.Password = Console.ReadLine();
            Console.SetCursorPosition(80, 39);
            pm.Password = Console.ReadLine();
            ChangeCaptcha:
            cap = LoginPage.GetCapchaCode();
            Console.SetCursorPosition(40, 41);
                Console.Write("||              Your captcha is:     "+cap+"                                                 " +   " ||");
            Console.SetCursorPosition(40, 43);
                Console.Write("||              Enter captcha:                                                               ||");

            Console.SetCursorPosition(80, 43);
            pm.Captcha = Console.ReadLine();
            Console.SetCursorPosition(40, 45);
            Console.WriteLine("||                                                                                           ||");
            Console.SetCursorPosition(40, 47);
            Console.WriteLine("||-------------------------------------------------------------------------------------------||");

            pm.UserId = LoginPage.GenerateUserId();

            //  pm.Added_OnDT = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            if (cap == pm.Captcha)
            {
                MyCommand = "Insert into FarmerApplyScheme values('" + pm.AdharNo + "','" + pm.Name + "','" + pm.MobileNo + "','" + pm.State + "','" + pm.Password + "','" + pm.Captcha + "','" + pm.UserId + "')";
                Status = dm.ExecuteMyInsertUpdateOrDelete(MyCommand);

                if (Status == true)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.SetCursorPosition(60, 50);
                    Console.WriteLine("Your details saved successfully.");
                    Console.SetCursorPosition(60, 53);

                    Console.WriteLine("Your Id for login: " + pm.UserId + "\t Password is:  " + pm.Password);
                }
                else
                {
                    Console.SetCursorPosition(60, 43);
                    Console.WriteLine("Sorry! unable to save your details.");
                }
            }
            else
            {
               // Console.WriteLine("Incorrect Captcha code: ");
               // cap = LoginPage.GetCapchaCode();
                goto ChangeCaptcha;
            }
           // Console.SetCursorPosition(20, 41);
        }
    }
}
