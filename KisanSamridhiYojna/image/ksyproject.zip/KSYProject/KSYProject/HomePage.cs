﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    class HomePage
    {
       internal void HomeSection()
        {
          // Console.WindowHeight = 50;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(65, 19);
            //Farmer Heading part
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(65, 20);
            Console.WriteLine("||   WELCOME FARMER IN OUR SITE   ||");
            Console.SetCursorPosition(65, 21);
            Console.WriteLine("||********************************||");
            //First left box
            Console.SetCursorPosition(34, 26);
            Console.WriteLine("||----------------------------------------||");
            Console.SetCursorPosition(34, 27);
            Console.WriteLine("||                                        ||");
            Console.SetCursorPosition(34, 28);
            Console.WriteLine("|| According to the Indian Government     ||");
            Console.SetCursorPosition(34, 29);
            Console.WriteLine("|| there are approx 14.5 Crores Farmer    ||");
            Console.SetCursorPosition(34, 30);
            Console.WriteLine("|| Family.About 58% of the Indian depends ||");
            Console.SetCursorPosition(34, 31);
            Console.WriteLine("|| on agriculture for their livelihood    ||");
            Console.SetCursorPosition(34, 32);
            Console.WriteLine("||                                        ||");
            Console.SetCursorPosition(34, 33);
            Console.WriteLine("||----------------------------------------||");
            //first right box
            Console.SetCursorPosition(85, 26);
            Console.WriteLine("||----------------------------------------||");
            Console.SetCursorPosition(85, 27);
            Console.WriteLine("||                                        ||");
            Console.SetCursorPosition(85, 28);
            Console.WriteLine("|| According to the Indian Government     ||");
            Console.SetCursorPosition(85, 29);
            Console.WriteLine("|| there are approx 14.5 Crores Farmer    ||");
            Console.SetCursorPosition(85, 30);
            Console.WriteLine("|| Family.About 58% of the Indian depends ||");
            Console.SetCursorPosition(85, 31);
            Console.WriteLine("|| on agriculture for their livelihood    ||");
            Console.SetCursorPosition(85, 32);
            Console.WriteLine("||                                        ||");
            Console.SetCursorPosition(85, 33);
            Console.WriteLine("||----------------------------------------||");

        }
    }
}

