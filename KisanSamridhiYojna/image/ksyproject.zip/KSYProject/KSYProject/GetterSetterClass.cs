﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    class GetterSetterClass
    {
      
            public string AdharNo { get; set; }
            public string Name { get; set; }
            public string MobileNo { get; set; }
            public string State { get; set; }
            public string Password { get; set; }
            public string Captcha { get; set; }
            public string UserId { get; set; }
            public string Status { get; set; }
            public float CAmount { get; set; }
    }
}
