﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace KSYProject
{
    internal class LoginPage
    {
        internal static string GenerateUserId()
        {
            string userid = "KSY";


            Random rc = new Random();

            char ch;
            ch = (char)rc.Next(54, 57);
            userid = userid + ch;
            ch = (char)rc.Next(52, 54);
            userid = userid + ch;

            ch = (char)rc.Next(50, 52);
            userid = userid + ch;
            ch = (char)rc.Next(48, 57);

            ch = (char)rc.Next(49, 53);
            userid = userid + ch;
            ch = (char)rc.Next(48, 57);
            userid = userid + ch;
            //ch = (char)rc.Next(3, 9);
            // code = code + ch;
            ch = (char)rc.Next(50, 54);
            userid = userid + ch;
            ch = (char)rc.Next(52, 57);
            userid = userid + ch;
            return userid;
        }
        //for generating captch code
        internal static string GetCapchaCode()
        {


            string code = string.Empty;
            Random rc = new Random();

            char ch;
            ch = (char)rc.Next(65, 91);
            code = code + ch;
            ch = (char)rc.Next(100, 120);
            code = code + ch;
            //ch = (char)rc.Next(3, 9);
            // code = code + ch;
            ch = (char)rc.Next(97, 122);
            code = code + ch;
            ch = (char)rc.Next(70, 90);
            code = code + ch;


            return code;
        }


        //VAILIDATE USERID

        internal static string MatchUseId()
        {
            string captchcode = GenerateUserId();
            string finalcaptcha = string.Empty;

            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();
            // bool Status;

            MyCommand = "Select UserId from FarmerApplyScheme ";
            DataTable dt = dm.ExecuteMyselect(MyCommand);

            foreach (DataRow dr in dt.Rows)
            {
                pm.UserId = (dr["UserId"].ToString());

                if (pm.UserId == captchcode)
                {

                    Console.WriteLine("Please try again somethig wrong:");
                    GenerateUserId();
                    break;

                }
                else
                {
                    finalcaptcha = captchcode;
                }
            }

            return finalcaptcha;

        }

        //formerlogin
        internal static void FormerLogin()
        {
            bool userFound = false;
            string cap;
            string Inpass, Incapcha, InUserId;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(65, 19);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(65, 20);
            Console.WriteLine("||       FARMER LOGIN PAGE        ||");
            Console.SetCursorPosition(65, 21);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(50, 28);
            Console.WriteLine("||-------------------------------------------------------------------||");
            Console.SetCursorPosition(50, 29);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 30);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 31);
                Console.Write("||           Enter User Id:-                                         ||");
            Console.SetCursorPosition(90, 31);
            InUserId = Console.ReadLine();
            Console.SetCursorPosition(50, 32);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 33);
               Console.Write("||           Enter Password:-                                        ||");

            Console.SetCursorPosition(90, 33);
            Inpass = Console.ReadLine();
            Console.SetCursorPosition(50, 34);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 35);
            cap = GetCapchaCode();
               Console.Write("||            Your captcha is:      " + cap + "                             ||");
            Console.SetCursorPosition(50, 36);
               Console.Write("||           Enter captcha:                                          ||");
            Console.SetCursorPosition(90, 36);
            Incapcha = Console.ReadLine();
            Console.SetCursorPosition(50, 37);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 38);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 39);
            Console.WriteLine("||-------------------------------------------------------------------||");

            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();
            // bool Status;

            MyCommand = "Select * from FarmerApplyScheme ";
            DataTable dt = dm.ExecuteMyselect(MyCommand);
            Console.WriteLine(pm.UserId + " " + pm.Password);
            foreach (DataRow dr in dt.Rows)
            {

                pm.Password = dr[4].ToString();
                pm.UserId = (dr[6].ToString());

                if (pm.Password == Inpass && cap == Incapcha && pm.UserId == InUserId)
                {
                    Console.Clear();
                    FarmerSelectionPage fsp = new FarmerSelectionPage(InUserId);
                    FarmerSelectionPage.FarmerSwitch();
                    userFound = true;
                   
                    //fsp.GetAdharNo(pm.Password,pm.UserId);
                    break;
                }
            }

            if (!userFound)
            {
                Console.SetCursorPosition(70, 43);
                Console.ForegroundColor = ConsoleColor.DarkRed;
                
                Console.WriteLine("User not found!");
            }
       
        }
    }
}
