﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace KSYProject
{
   
    //int ChoiseForFarmerMenu;
    internal class FarmerSelectionPage
    {
        internal static string cap, id;
        public FarmerSelectionPage(string id1)
        {
            cap = string.Empty;
            id = id1;
        }
        
        //ShowFarmerProfile
        internal static void Profile(string id)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();
            //Console.SetCursorPosition(40, 20);
            //Console.WriteLine("Enter Your Adhar No.:");
            //Console.SetCursorPosition(60, 20);
           // string FarmerAdhar = Console.ReadLine();
            MyCommand = "Select * from FarmerApplyScheme where UserId='"+id+"'";
            DataTable dt = dm.ExecuteMyselect(MyCommand);
            foreach (DataRow dr in dt.Rows)
            {

                pm.AdharNo = dr[0].ToString();
                pm.Name = dr[1].ToString();
                pm.MobileNo = (dr[2].ToString());
                pm.State = dr[3].ToString();
                pm.Password = dr[4].ToString();             
                pm.UserId = (dr[6].ToString());
                // Console.WriteLine(dr[0] + "\t" + dr[1] + "\t" + dr[2] + "\t" + dr[3] + "\t" + dr[4] + "\t" + dr[5]);
                Console.SetCursorPosition(63, 23);
                Console.WriteLine("Your Adhar No. :- "+pm.AdharNo);
                Console.SetCursorPosition(63, 24);
                Console.WriteLine("Your Name is. :- "+pm.Name);
                Console.SetCursorPosition(63, 25);
                Console.WriteLine("Your Mobile No :- "+pm.MobileNo);
                Console.SetCursorPosition(63, 26);
                Console.WriteLine("Your State :- "+pm.State);
                Console.SetCursorPosition(63, 28);
                Console.WriteLine("Your UserId. :- "+pm.UserId);
                Console.SetCursorPosition(63, 27);
                Console.WriteLine("Your Password :- " + pm.Password);
            }


        }
        //UPDATE FARMER RECORD
        internal static void UpdateFarmerRecord()
        {
            bool Status = true;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();

            Console.SetCursorPosition(70, 21);
            Console.Write("Enter your AatharNo: ");
           
            pm.AdharNo = Console.ReadLine();
            MyCommand = "select AdharNo from FarmerApplyScheme where AdharNo='" + pm.AdharNo+ "'";
            object obj = dm.GetSingleValue(MyCommand);
            if (obj != null)
            {
                Console.SetCursorPosition(70, 22);
                Console.WriteLine("Enter Updated details of  farmar: ");
                Console.SetCursorPosition(70, 23);
                Console.Write("Enter Farmer Name: ");
               
                pm.Name = Console.ReadLine();
                Console.SetCursorPosition(70, 24);
                Console.Write("Enter Mobile number: ");
                
                pm.MobileNo = (Console.ReadLine());
                Console.SetCursorPosition(70, 25);
                Console.Write("Enter Your State: ");
               
                pm.State = Console.ReadLine();

                //  pm.Added_OnDT = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
                MyCommand = "Update FarmerApplyScheme set  Name='" + pm.Name + "',MobileNo='" + pm.MobileNo + "',State='" + pm.State + "' where AdharNo='" + pm.AdharNo + "'";
                Status = dm.ExecuteMyInsertUpdateOrDelete(MyCommand);
                if (Status == true)
                {
                    Console.SetCursorPosition(70, 30);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Record updated successfully.");
                }
                else
                {
                    Console.SetCursorPosition(70, 30);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Sorry! unable to update farmer details.");
                }
            }
            else
            {
                Console.SetCursorPosition(70, 30);
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Sorry this record not found in database.");
            }
        }
        //apply for scheme
        internal static void ApplyForScheme()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            string applyrecord;
            Registration dm = new Registration();
            Console.SetCursorPosition(60, 20);
            Console.WriteLine("Hello Farmer! We are glad to have you here.");
            Console.SetCursorPosition(58, 21);
            Console.WriteLine("====================================================");
            Console.SetCursorPosition(60, 23);
            Console.WriteLine("Please Apply For The Kisan Samriddhi Yojna");
            Console.SetCursorPosition(60, 25);
            Console.Write("Enter Your Adhar No.: ");
            
            pm.AdharNo = Console.ReadLine();
            Console.SetCursorPosition(60, 26);
            Console.Write("Enter 'Y' for Apply and 'N' for Quit:");
         //   Console.SetCursorPosition(80, 26);
            char ch = char.Parse(Console.ReadLine());
            MyCommand="Select CAmount from ApplyScheme where AdharNo='"+pm.AdharNo+"'";
            object GetCAmount = dm.GetSingleValue(MyCommand);
            
            if (ch == 'y' || ch == 'Y')
            {
                if (GetCAmount==null)
                {
                    applyrecord = "Applied";
                    pm.CAmount = 0;
                    MyCommand = "Insert into ApplyScheme (AdharNo,SchemeApply,CAmount) values('" + pm.AdharNo + "','" + applyrecord + "','" + pm.CAmount + "')";
                    bool Status = dm.ExecuteMyInsertUpdateOrDelete(MyCommand);
                    if (Status == true)
                    {
                        Console.SetCursorPosition(70, 30);
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Applied Successfully.");
                    }
                    else
                    {
                        Console.SetCursorPosition(70, 30);
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Sorry! Unable to Applied.");
                    }
                }
                else
                {
                    Console.SetCursorPosition(70, 30);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("You Have Already Apply For This Scheme.");
                }
            }
        }

        //Farmer Current Amount
        internal static void CurrentFarmerAmount()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            string InAdharNo = string.Empty;
           /* Console.SetCursorPosition(40, 20);
            Console.WriteLine("Enter adhar number for check total amount:");
            Console.SetCursorPosition(40, 21);
            InAdharNo = Console.ReadLine();*/
            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();
            // bool Status;

            MyCommand = "Select * from FarmerApplyScheme inner join ApplyScheme on FarmerApplyScheme.AdharNo=ApplyScheme.AdharNo";
            DataTable dt = dm.ExecuteMyselect(MyCommand);

            foreach (DataRow dr in dt.Rows)
            {
                pm.UserId = dr["UserId"].ToString();
                if (pm.UserId== id)
                {
                    Console.SetCursorPosition(60, 22);
                    Console.WriteLine("||===========================================||");
                    Console.SetCursorPosition(60, 23);
                    Console.WriteLine("||           Total Amount:        " + float.Parse(dr["CAmount"].ToString())+"         ||");
                    Console.SetCursorPosition(60, 24);
                    Console.WriteLine("||===========================================||");
                    break;

                }
                else
                {
                    continue;
                }
            }

        }
        //Farmer Current Status Update
        internal static void CurrentFarmerStatus()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            string InAdharNo = string.Empty;
            Console.SetCursorPosition(60, 20);
            Console.Write("Enter adhar number for check total amount: ");
            
            InAdharNo = Console.ReadLine();
            GetterSetterClass pm = new GetterSetterClass();
            string MyCommand = string.Empty;
            Registration dm = new Registration();
            // bool Status;

            MyCommand = "Select * from ApplyScheme ";
            DataTable dt = dm.ExecuteMyselect(MyCommand);

            foreach (DataRow dr in dt.Rows)
            {
                pm.AdharNo = dr["AdharNo"].ToString();
                pm.CAmount =float.Parse( dr["CAmount"].ToString());
            
                if (pm.AdharNo == InAdharNo)
                {

                    if(pm.CAmount==0)
                    {
                        Console.SetCursorPosition(60, 25);
                        Console.WriteLine("Your scheme installment wil be credited in your account soon.");
                    }
                    else
                    {
                        Console.SetCursorPosition(60, 25);
                        Console.WriteLine("Your scheme installment credited in your account.");
                    }
                    break;
                }
                else
                {
                    Console.SetCursorPosition(60, 25);
                    Console.WriteLine("You are not Apply for this scheme.");
                }
            }

        }
        internal static void FarmerSwitch()
        {
           
        FarmerDashHeader.ShowMenu();

            while (true)
            {
                FarmerDashHeader fdh = new FarmerDashHeader();
                Console.SetCursorPosition(70, 18);
                Console.ForegroundColor = ConsoleColor.DarkRed;

                Console.Write("Enter your choice:");
                int ChoiseForFarmerMenu = int.Parse(Console.ReadLine());
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                fdh.LoginFooterSection();
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                switch (ChoiseForFarmerMenu)
                {
                    ////LOGIN NEW FARMER REGISTRATION
                    case 1:
                        Console.Clear();
                        FarmerDashHeader.ShowMenu();
                        Profile(id);
                        break;
                    case 2:
                        Console.Clear();
                        FarmerDashHeader.ShowMenu();
                        ApplyForScheme();
                        break;

                    case 3:
                        Console.Clear();
                        FarmerDashHeader.ShowMenu();
                        CurrentFarmerAmount();
                        break;
                    case 4:
                        //Update Farmer Details
                        Console.Clear();
                        FarmerDashHeader.ShowMenu();
                        UpdateFarmerRecord();
                        break;
                    case 5:
                        Console.Clear();
                        FarmerDashHeader.ShowMenu();
                        CurrentFarmerStatus();
                        break;
                    case 6:
                        Environment.Exit(1);
                        break;
                }
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                fdh.LoginFooterSection();

            } 
        }


    }
}

