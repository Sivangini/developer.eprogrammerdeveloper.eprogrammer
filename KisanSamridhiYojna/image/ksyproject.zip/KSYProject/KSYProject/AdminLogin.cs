﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KSYProject
{
    internal class AdminLogin
    {
        internal void AdminDash()
        {

            do
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("                      _____  __  __            _  ___                     _____                      _     _ _     _   __     __   _             \r\n                     |  __ \\|  \\/  |          | |/ (_)                   / ____|                    (_)   | | |   (_)  \\ \\   / /  (_)            \r\n                     | |__) | \\  / |  ______  | ' / _ ___  __ _ _ __    | (___   __ _ _ __ ___  _ __ _  __| | |__  _    \\ \\_/ /__  _ _ __   __ _ \r\n                     |  ___/| |\\/| | |______| |  < | / __|/ _` | '_ \\    \\___ \\ / _` | '_ ` _ \\| '__| |/ _` | '_ \\| |    \\   / _ \\| | '_ \\ / _` |\r\n                     | |    | |  | |          | . \\| \\__ \\ (_| | | | |   ____) | (_| | | | | | | |  | | (_| | | | | |     | | (_) | | | | | (_| |\r\n                     |_|    |_|  |_|          |_|\\_\\_|___/\\__,_|_| |_|  |_____/ \\__,_|_| |_| |_|_|  |_|\\__,_|_| |_|_|     |_|\\___/| |_| |_|\\__,_|\r\n                                                                                                                                 _/ |            \r\n                                                                                                                                |__/             ");
                Console.WriteLine("".PadLeft((Console.WindowWidth - 90) / 2)); // Centering

                // Set text colors for each option

                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("+***********************************************************************************************************************************************************************++");
                Console.WriteLine("||+*********************************************************************************************************************************************************************||");
                Console.WriteLine("||                                                                                                                                                                      ||");
                Console.WriteLine("|| 1.Registered Farmers   ||  2.Farmers' Application   ||  3.Make Payment   ||   4.Delete Farmer   ||   5.Delete Application   ||   6.Search Farmer Details   ||  7.Exit ||");
                Console.WriteLine("||                                                                                                                                                                      ||");
                Console.WriteLine("||++*******************************************************************************************************************************************************************+||");
                Console.Write("++**********************************************************************************************************************************************************************++");
                
          
                int x;
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.SetCursorPosition(70, 18);
                Console.Write("Select Option -:");
                x = int.Parse(Console.ReadLine());
                PaymentManager PaymentM = new PaymentManager();
                Console.ForegroundColor = ConsoleColor.DarkGreen;

                switch (x)
                {

                    case 1:
                        PaymentM.GetFarmerDetails();
                        break;
                    case 2:
                        PaymentM.GetFarmerApplication();
                        break;
                    case 3:
                        PaymentM.MakePayment();
                        break;
                    case 4:
                        PaymentM.DeleteFarmerDetaails();
                        break;
                    case 5:
                        PaymentM.DeleteFarmerApplication();
                        break;
                    case 6:
                        PaymentM.SearchFarmerDeatails();
                        break;
                    case 7:
                        Environment.Exit(0);
                        break;
                }
                Console.ReadKey();
                Console.Clear();
            } while (true);
        }
        internal bool AdminLogin1()
        {
            string InUserId, InPass;
            bool result;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(65, 19);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(65, 20);
            Console.WriteLine("||        ADMIN LOGIN PAGE        ||");
            Console.SetCursorPosition(65, 21);
            Console.WriteLine("||********************************||");
            Console.SetCursorPosition(50, 28);
            Console.WriteLine("||-------------------------------------------------------------------||");
            Console.SetCursorPosition(50, 29);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 30);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 31);
            Console.Write("||           Enter User Id:-                                         ||");
            Console.SetCursorPosition(90, 31);
            InUserId = Console.ReadLine();
            Console.SetCursorPosition(50, 32);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 33);
            Console.Write("||           Enter Password:-                                        ||");

            Console.SetCursorPosition(90, 33);
            InPass = Console.ReadLine();
            Console.SetCursorPosition(50, 34);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 35);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 36);
            Console.WriteLine("||                                                                   ||");
            Console.SetCursorPosition(50, 37);
            Console.WriteLine("||-------------------------------------------------------------------||");
            if(InUserId=="MainAdmin123" && InPass=="Admin@123")
            {
                result=true;
            }
            else
            {
                result = false;
            }
            return result;
        }
    }
}
