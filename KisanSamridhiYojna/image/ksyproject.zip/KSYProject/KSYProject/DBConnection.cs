﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace KSYProject
{
    internal class Registration
    {
        SqlConnection conn;

        public Registration()
        {
            conn = new SqlConnection("Data Source=SUBHAM\\SQLEXPRESS;Initial Catalog=KSYDB;Integrated Security=True;");
        }
        internal bool ExecuteMyInsertUpdateOrDelete(string CommandText)
        {
            SqlCommand cmd = new SqlCommand(CommandText, conn);

            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            int n = cmd.ExecuteNonQuery();
            conn.Close();
            return n > 0 ? true : false;
        }
        internal DataTable ExecuteMyselect(string CommandText)
        {
            SqlDataAdapter da = new SqlDataAdapter(CommandText, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
        internal object GetSingleValue(string CommandText)
        {
            SqlCommand cmd = new SqlCommand(CommandText, conn);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            object res = cmd.ExecuteScalar();



            conn.Close();
            return res;

        }


    }
}
